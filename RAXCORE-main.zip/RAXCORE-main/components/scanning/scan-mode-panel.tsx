'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { Camera, X, RotateCcw, Check, ChevronRight, ShieldCheck } from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  type ScanAngle,
  type SmartScanFrame,
  type SubjectValidation,
  type CoverageProgress,
  analyseFrame,
  detectCoverageZones,
  buildCoverageProgress,
  framesToLegacySlots,
  buildGuidanceState,
} from '@/lib/capture/scan-session'
import { toast } from 'sonner'

// ─── Zone metadata ─────────────────────────────────────────────────────────────

const REQUIRED_SCAN_ANGLES = ['front', 'left', 'right'] as const satisfies readonly ScanAngle[]

const ZONE_LABELS: Record<keyof CoverageProgress['zones'], string> = {
  full_rack: 'Front',
  left_antler: 'Left',
  right_antler: 'Right',
  beam_tine_detail: 'Detail',
}

const ZONE_ARCS: Record<keyof CoverageProgress['zones'], { startDeg: number; spanDeg: number }> = {
  full_rack: { startDeg: 270, spanDeg: 120 },
  left_antler: { startDeg: 30, spanDeg: 120 },
  right_antler: { startDeg: 150, spanDeg: 120 },
  beam_tine_detail: { startDeg: 0, spanDeg: 0 },
}

const ANGLE_TO_ZONE: Record<ScanAngle, keyof CoverageProgress['zones']> = {
  front: 'full_rack',
  left: 'left_antler',
  right: 'right_antler',
  detail: 'beam_tine_detail',
}

function polarToXY(cx: number, cy: number, r: number, deg: number) {
  const rad = ((deg - 90) * Math.PI) / 180
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) }
}

function arcPath(cx: number, cy: number, r: number, startDeg: number, spanDeg: number) {
  const gapDeg = 5
  const s = polarToXY(cx, cy, r, startDeg + gapDeg / 2)
  const e = polarToXY(cx, cy, r, startDeg + spanDeg - gapDeg / 2)
  const large = spanDeg - gapDeg > 180 ? 1 : 0
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`
}

function CapturePlanRing({ progress, size = 180 }: { progress: CoverageProgress; size?: number }) {
  const cx = size / 2
  const cy = size / 2
  const r = size / 2 - 14

  return (
    <svg width={size} height={size} className="absolute inset-0" aria-hidden>
      {REQUIRED_SCAN_ANGLES.map((angle) => {
        const zone = ANGLE_TO_ZONE[angle]
        const filled = progress.zones[zone]
        const { startDeg, spanDeg } = ZONE_ARCS[zone]
        return (
          <path
            key={zone}
            d={arcPath(cx, cy, r, startDeg, spanDeg)}
            fill="none"
            stroke={filled ? 'hsl(var(--primary))' : 'rgba(255,255,255,0.18)'}
            strokeWidth={8}
            strokeLinecap="round"
            style={{ transition: 'stroke 0.4s ease' }}
          />
        )
      })}
    </svg>
  )
}

function FrameStrip({
  frames,
  onRemove,
}: {
  frames: SmartScanFrame[]
  onRemove: (id: string) => void
}) {
  if (frames.length === 0) return null

  return (
    <div className="flex gap-2 overflow-x-auto pb-0.5" style={{ scrollbarWidth: 'none' }}>
      {frames.map((frame) => (
        <div
          key={frame.id}
          className="relative h-14 w-14 shrink-0 overflow-hidden rounded-xl border border-border/50"
        >
          <img src={frame.previewUrl} alt={`${frame.angle} capture`} className="h-full w-full object-cover" />
          <button
            type="button"
            onClick={() => onRemove(frame.id)}
            className="absolute right-0.5 top-0.5 flex h-5 w-5 touch-manipulation items-center justify-center rounded-full bg-black/70"
            aria-label="Remove"
          >
            <X className="h-3 w-3 text-white" />
          </button>
          <span className="absolute inset-x-0 bottom-0 bg-black/55 py-0.5 text-center text-[9px] font-medium capitalize text-white">
            {frame.angle}
          </span>
        </div>
      ))}
    </div>
  )
}

interface ScanModePanelProps {
  onFilesReady: (files: File[], angles: ScanAngle[]) => void
  onFallbackToUpload?: () => void
}

export function ScanModePanel({ onFilesReady, onFallbackToUpload }: ScanModePanelProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const rafRef = useRef<number | null>(null)
  const lastUpdateRef = useRef(0)
  const isActiveRef = useRef(true)

  const [isStreaming, setIsStreaming] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [frames, setFrames] = useState<SmartScanFrame[]>([])
  const [progress, setProgress] = useState<CoverageProgress>(buildCoverageProgress([]))
  const [validation, setValidation] = useState<SubjectValidation | null>(null)
  const [angleHint, setAngleHint] = useState<ScanAngle>('front')
  const [flashVisible, setFlashVisible] = useState(false)
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment')

  const guidance = buildGuidanceState(validation, progress, isStreaming)
  const capturedRequiredCount = REQUIRED_SCAN_ANGLES.filter((angle) => progress.zones[ANGLE_TO_ZONE[angle]]).length

  const stopCamera = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current)
      rafRef.current = null
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    if (videoRef.current) videoRef.current.srcObject = null
    setIsStreaming(false)
  }, [])

  const startCamera = useCallback(async (facing: 'environment' | 'user') => {
    if (!isActiveRef.current) return
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setCameraError('Camera is not available in this browser. Use upload instead.')
      return
    }

    setCameraError(null)

    try {
      stopCamera()

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facing },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      })

      if (!isActiveRef.current) {
        stream.getTracks().forEach((track) => track.stop())
        return
      }

      streamRef.current = stream
      const video = videoRef.current
      if (video) {
        video.srcObject = stream
        await video.play()
      }

      if (!isActiveRef.current) {
        stream.getTracks().forEach((track) => track.stop())
        return
      }

      setIsStreaming(true)
    } catch (err) {
      if (!isActiveRef.current) return
      if (err instanceof DOMException && err.name === 'AbortError') return

      console.warn('[scan-mode] camera initialization failed', err)
      setCameraError('Camera access failed. Retry or switch to upload.')
      setIsStreaming(false)
    }
  }, [stopCamera])

  useEffect(() => {
    isActiveRef.current = true
    startCamera(facingMode)

    return () => {
      isActiveRef.current = false
      stopCamera()
    }
  }, [facingMode, startCamera, stopCamera])

  // Optical-quality analysis only. No auto-capture. No fake deer/rack detection.
  useEffect(() => {
    if (!isStreaming) return

    let lastTick = 0
    const TICK_MS = 350

    const loop = (rafTime: number) => {
      rafRef.current = requestAnimationFrame(loop)
      if (rafTime - lastTick < TICK_MS) return
      lastTick = rafTime

      const video = videoRef.current
      const canvas = canvasRef.current
      if (!video || !canvas || video.readyState < 2 || video.videoWidth === 0 || video.videoHeight === 0) return

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight
      const ctx = canvas.getContext('2d', { willReadFrequently: true })
      if (!ctx) return
      ctx.drawImage(video, 0, 0)

      const result = analyseFrame(canvas)
      const now = Date.now()
      if (now - lastUpdateRef.current > 160) {
        setValidation(result)
        lastUpdateRef.current = now
      }
    }

    rafRef.current = requestAnimationFrame(loop)
    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current)
        rafRef.current = null
      }
    }
  }, [isStreaming])

  useEffect(() => {
    setProgress(buildCoverageProgress(frames))
  }, [frames])

  useEffect(() => {
    if (angleHint === 'front' && progress.zones.full_rack && !progress.zones.left_antler) setAngleHint('left')
    else if (angleHint === 'left' && progress.zones.left_antler && !progress.zones.right_antler) setAngleHint('right')
  }, [angleHint, progress.zones.full_rack, progress.zones.left_antler, progress.zones.right_antler])

  const captureFrameAsync = useCallback((
    angle: ScanAngle,
    zones: ReturnType<typeof detectCoverageZones>,
    val: SubjectValidation,
  ) => {
    const video = videoRef.current
    if (!video || video.readyState < 2 || video.videoWidth === 0 || video.videoHeight === 0) {
      toast.error('Camera is not ready yet')
      return
    }

    const cap = document.createElement('canvas')
    cap.width = video.videoWidth
    cap.height = video.videoHeight
    const ctx = cap.getContext('2d')
    if (!ctx) return
    ctx.drawImage(video, 0, 0)

    cap.toBlob((blob) => {
      if (!blob) return

      const file = new File([blob], `scan-${angle}-${Date.now()}.jpg`, { type: 'image/jpeg' })
      const previewUrl = URL.createObjectURL(blob)
      const frame: SmartScanFrame = {
        id: crypto.randomUUID(),
        file,
        previewUrl,
        capturedAt: new Date().toISOString(),
        zones,
        validation: val,
        angle,
      }

      setFrames((prev) => {
        const replaced = prev.find((existing) => existing.angle === angle)
        if (replaced) URL.revokeObjectURL(replaced.previewUrl)
        return [...prev.filter((existing) => existing.angle !== angle), frame]
      })

      setFlashVisible(true)
      window.setTimeout(() => setFlashVisible(false), 140)
      if (navigator.vibrate) navigator.vibrate(35)
    }, 'image/jpeg', 0.9)
  }, [])

  const handleManualCapture = useCallback(() => {
    const val: SubjectValidation = validation ?? {
      hasDeer: false,
      hasRack: false,
      isSharp: true,
      isClipped: false,
      brightnessOk: true,
      confidence: 0.55,
      rejectionReason: null,
    }

    if (val.rejectionReason) {
      toast.error(val.rejectionReason)
      return
    }

    const zones = detectCoverageZones(val, angleHint)
    captureFrameAsync(angleHint, zones, val)
  }, [validation, angleHint, captureFrameAsync])

  const handleRemoveFrame = useCallback((id: string) => {
    setFrames((prev) => {
      const removed = prev.find((frame) => frame.id === id)
      if (removed) URL.revokeObjectURL(removed.previewUrl)
      return prev.filter((frame) => frame.id !== id)
    })
  }, [])

  const handleFlipCamera = useCallback(() => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'))
  }, [])

  const handleReset = useCallback(() => {
    frames.forEach((frame) => URL.revokeObjectURL(frame.previewUrl))
    setFrames([])
    setAngleHint('front')
  }, [frames])

  const handleFinalize = useCallback(() => {
    if (frames.length === 0) {
      toast.error('Capture at least one front view to continue')
      return
    }
    if (!progress.zones.full_rack) {
      toast.error('Capture the front full-rack view first')
      return
    }

    const { files, angles } = framesToLegacySlots(frames)
    if (files.length === 0) {
      toast.error('No valid frames captured')
      return
    }

    if (!progress.satisfied) {
      toast.warning('Side views are missing. You can score, but confidence may be lower.')
    }

    onFilesReady(files, angles)
  }, [frames, onFilesReady, progress.satisfied, progress.zones.full_rack])

  const borderColor =
    guidance.status === 'valid' ? 'border-primary/70' :
    guidance.status === 'invalid' ? 'border-destructive/60' :
    'border-white/15'

  return (
    <div className="space-y-4">
      <div
        className={cn(
          'relative aspect-[3/4] w-full overflow-hidden rounded-2xl border-2 bg-black transition-colors duration-300',
          borderColor,
        )}
      >
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="absolute inset-0 h-full w-full object-cover"
        />
        <canvas ref={canvasRef} className="sr-only" aria-hidden />

        {flashVisible && <div className="pointer-events-none absolute inset-0 bg-white/25" />}

        {cameraError && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-black/85 text-white">
            <Camera className="h-10 w-10 opacity-50" />
            <p className="px-6 text-center text-sm">{cameraError}</p>
            <button
              type="button"
              onClick={() => startCamera(facingMode)}
              className="touch-manipulation text-xs text-white/70 underline hover:text-white"
            >
              Tap to retry
            </button>
            {onFallbackToUpload && (
              <button
                type="button"
                onClick={onFallbackToUpload}
                className="mt-2 touch-manipulation rounded-lg bg-white/10 px-4 py-2 text-sm font-medium hover:bg-white/20"
              >
                Switch to Upload
              </button>
            )}
          </div>
        )}

        {isStreaming && !cameraError && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <div className="relative" style={{ width: 180, height: 180 }}>
              <CapturePlanRing progress={progress} size={180} />
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-0.5">
                <span className="font-mono text-2xl font-bold tabular-nums text-white">
                  {capturedRequiredCount}/3
                </span>
                <span className="text-[11px] font-medium text-white/60">views captured</span>
              </div>
            </div>
            <div className="mt-3 flex gap-3">
              {REQUIRED_SCAN_ANGLES.map((angle) => {
                const zone = ANGLE_TO_ZONE[angle]
                const filled = progress.zones[zone]
                return (
                  <div key={zone} className="flex items-center gap-1">
                    <div className={cn('h-1.5 w-1.5 rounded-full', filled ? 'bg-primary' : 'bg-white/25')} />
                    <span className={cn('text-[10px] font-medium', filled ? 'text-white' : 'text-white/45')}>
                      {ZONE_LABELS[zone]}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {isStreaming && !cameraError && (
          <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent px-4 pb-24 pt-12">
            <div className="mx-auto max-w-sm rounded-2xl border border-white/10 bg-black/35 px-3 py-2 backdrop-blur-sm">
              <div className="mb-1 flex items-center justify-center gap-1.5 text-[10px] font-medium uppercase tracking-[0.22em] text-primary/85">
                <ShieldCheck className="h-3 w-3" />
                guided manual capture
              </div>
              <p
                className={cn(
                  'text-center text-sm font-semibold leading-snug',
                  guidance.status === 'invalid' ? 'text-red-400' : 'text-white',
                )}
              >
                {guidance.headline}
              </p>
              {guidance.subtext && <p className="mt-0.5 text-center text-xs text-white/55">{guidance.subtext}</p>}
            </div>
          </div>
        )}

        {isStreaming && (
          <button
            type="button"
            onClick={handleFlipCamera}
            className="absolute right-3 top-3 flex h-9 w-9 touch-manipulation items-center justify-center rounded-full bg-black/50 backdrop-blur-sm"
            aria-label="Flip camera"
          >
            <RotateCcw className="h-4 w-4 text-white" />
          </button>
        )}

        {isStreaming && !cameraError && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
            <button
              type="button"
              onClick={handleManualCapture}
              className="flex h-16 w-16 touch-manipulation items-center justify-center rounded-full border-4 border-white/80 bg-white/20 shadow-lg backdrop-blur-sm transition-transform active:scale-95"
              aria-label="Capture photo"
            >
              <div className="h-11 w-11 rounded-full bg-white" />
            </button>
          </div>
        )}
      </div>

      <div className="flex gap-1.5">
        {REQUIRED_SCAN_ANGLES.map((angle) => {
          const zone = ANGLE_TO_ZONE[angle]
          const done = progress.zones[zone]
          const active = angleHint === angle
          return (
            <button
              key={angle}
              type="button"
              onClick={() => setAngleHint(angle)}
              className={cn(
                'flex flex-1 touch-manipulation items-center justify-center gap-1.5 rounded-xl border py-2.5 text-xs font-semibold capitalize transition-all',
                done
                  ? 'border-primary/30 bg-primary/15 text-primary'
                  : active
                    ? 'border-border bg-card text-foreground shadow-sm'
                    : 'border-border/40 bg-transparent text-muted-foreground hover:text-foreground',
              )}
            >
              {done && <Check className="h-3 w-3" />}
              {angle}
            </button>
          )
        })}
      </div>

      <div className="rounded-xl border border-border/60 bg-card/60 p-3 text-xs text-muted-foreground">
        This camera mode does <span className="font-semibold text-foreground">not</span> auto-capture or fake rack detection. It only checks basic photo quality here; deer/rack validation happens in the scoring AI after upload.
      </div>

      {frames.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-muted-foreground">
              {frames.length} frame{frames.length !== 1 ? 's' : ''} captured
            </span>
            <button
              type="button"
              onClick={handleReset}
              className="flex touch-manipulation items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
            >
              <RotateCcw className="h-3 w-3" />
              Reset
            </button>
          </div>
          <FrameStrip frames={frames} onRemove={handleRemoveFrame} />
        </div>
      )}

      {frames.length > 0 && (
        <button
          type="button"
          onClick={handleFinalize}
          className={cn(
            'flex min-h-[52px] w-full touch-manipulation items-center justify-center gap-2 rounded-2xl text-sm font-semibold transition-all',
            progress.satisfied
              ? 'bg-primary text-primary-foreground shadow-md active:scale-[0.98]'
              : 'border border-border bg-card text-foreground hover:bg-secondary/60',
          )}
        >
          {progress.satisfied ? (
            <>
              <Check className="h-4 w-4" />
              Views ready — continue
            </>
          ) : (
            <>
              Continue with {frames.length} frame{frames.length !== 1 ? 's' : ''}
              <ChevronRight className="h-4 w-4" />
            </>
          )}
        </button>
      )}
    </div>
  )
}
